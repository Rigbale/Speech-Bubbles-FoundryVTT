Hooks.on('init', () => {
	Gamepad.settings.register("pointer", "", {
		name:,
		hint:,
		scope:,
		config:,
		default:,
		type:,
	})
});
